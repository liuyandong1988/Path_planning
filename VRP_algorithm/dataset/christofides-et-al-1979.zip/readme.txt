Data files

This instance is designed from the instances Christofides, Mingozzi, and Toth (1979) and Golden, Wasil, Kelly, and Chao (1998).

Each instance is composed of three files: times, nodes, and vehicles. For example
CMT1_medium: It reports the time matrix.
CMT1_nodes: It refers the coordenates (x,y) and demand
CMT1_vehicles: vehicles capacity, the lines represent the number of vehicles.